# ------------------------------------------------------------------------------------------ #
# Title: Assignment07
# Desc: This assignment demonstrates using functions, classes, and structured error handling
# Change Log: (Who, When, What)
#   Ivan Esley, 2/25/24, Created Script
# ------------------------------------------------------------------------------------------ #

import json

# Define the Data Constants
MENU: str = '''
---- Course Registration Program ----
  Select from the following menu:  
    1. Register a Student for a Course
    2. Show current data  
    3. Save data to a file
    4. Exit the program
----------------------------------------- 
'''
# Define the Data Constants
FILE_NAME: str = "Enrollments.json"

# Define the Data Variables and constants
students: list = []  # a table of student data
menu_choice: str  # Hold the choice made by the user.


class Person:     #A class to represent a person.
    """
    Attributes:
        first_name (str): The first name of the person.
        last_name (str): The last name of the person.
    """

    def __init__(self, first_name: str = "", last_name: str = ""):
        self.__first_name = first_name
        self.__last_name = last_name

    @property
    def first_name(self) -> str:
        return self.__first_name

    @first_name.setter
    def first_name(self, value: str):
        if value.isalpha():
            self.__first_name = value
        else:
            raise ValueError("First name should only contain alphabets.")

    @property
    def last_name(self) -> str:
        return self.__last_name

    @last_name.setter
    def last_name(self, value: str):
        if value.isalpha():
            self.__last_name = value
        else:
            raise ValueError("Last name should only contain alphabets.")

    def __str__(self) -> str:
        return f"{self.__first_name} {self.__last_name}"


class Student(Person):  #A class to represent a student, inherits from Person class
    """
    Attributes:
        course_name (str): The course name of the student.
    """

    def __init__(self, first_name: str = "", last_name: str = "", course_name: str = ""):
        super().__init__(first_name, last_name)
        self.__course_name = course_name

    @property
    def course_name(self) -> str:
        return self.__course_name

    @course_name.setter
    def course_name(self, value: str):
        self.__course_name = value

    def __str__(self) -> str:
        return f"{super().__str__()} is enrolled in {self.__course_name}"


class FileProcessor:  #A class to handle file operations
    """
    Methods:
        read_data_from_file(file_name: str, student_data: list) -> list: Read data from a file.
        write_data_to_file(file_name: str, student_data: list): Write data to a file.
        output_error_messages(message: str, error: Exception = None): Output error messages.
    """

    @staticmethod
    def read_data_from_file(file_name: str, student_data: list) -> list:   #Reads data from a file
        try:
            with open(file_name, "r") as file:
                student_data.extend(json.load(file))
        except Exception as e:
            FileProcessor.output_error_messages("Error: There was a problem with reading the file.", e)

    @staticmethod
    def write_data_to_file(file_name: str, student_data: list):  #Writes data to a file
        try:
            with open(file_name, "w") as file:
                json.dump(student_data, file)
                print("The following data was saved to file!")
                IO.output_student_courses(student_data)
        except Exception as e:
            FileProcessor.output_error_messages("Error: There was a problem with writing to the file.", e)

    @staticmethod
    def output_error_messages(message: str, error: Exception = None):    #Outputs error messages
        print(message)
        if error:
            print("-- Technical Error Message -- ")
            print(error.__doc__)
            print(error)


class IO:  #A class to handle input/output operations

    @staticmethod
    def input_student_data(student_data: list):   #Inputs student data
        try:
            student_first_name = input("Enter the student's first name: ")
            if not student_first_name.isalpha():
                raise ValueError("The first name should not contain numbers.")
            student_last_name = input("Enter the student's last name: ")
            if not student_last_name.isalpha():
                raise ValueError("The last name should not contain numbers.")
            course_name = input("Please enter the name of the course: ")
            student_data.append({"FirstName": student_first_name,
                                "LastName": student_last_name,
                                "CourseName": course_name})
            print(f"You have registered {student_first_name} {student_last_name} for {course_name}.")
        except ValueError as e:
            IO.output_error_messages(str(e))

    @staticmethod
    def output_menu(menu: str):   #Outputs the menu
        print(menu)

    @staticmethod
    def input_menu_choice():     #Inputs menu choice
        return input("What would you like to do: ")

    @staticmethod
    def output_student_courses(student_data: list):     #Outputs student courses
        print("-" * 50)
        for student in student_data:
            print(f'Student {student["FirstName"]} '
                  f'{student["LastName"]} is enrolled in {student["CourseName"]}')
        print("-" * 50)


# read the file data into a list of lists
FileProcessor.read_data_from_file(FILE_NAME, students)

# Present and Process the data
while True:
    IO.output_menu(MENU)
    menu_choice = IO.input_menu_choice()

    # Input user data
    if menu_choice == "1":
        IO.input_student_data(students)
        continue

    # Present the current data
    elif menu_choice == "2":
        IO.output_student_courses(students)
        continue

    # Save the data to a file
    elif menu_choice == "3":
        FileProcessor.write_data_to_file(FILE_NAME, students)
        continue

    # Stop the loop
    elif menu_choice == "4":
        break
    else:
        print("Please only choose option 1, 2, 3, or 4")

print("Program Ended")
